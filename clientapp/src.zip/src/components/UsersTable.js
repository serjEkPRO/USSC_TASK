import React, { useEffect, useState } from 'react';
import '../styles/UsersTable.css';

const UsersTable = ({ initialUsers = [], onUserClick }) => {
  const [users, setUsers] = useState(initialUsers);
  const [searchQuery, setSearchQuery] = useState('');

  const fetchUsers = async (query = '') => {
    try {
      const url = query ? `http://127.0.0.1:5000/search-users?query=${query}` : 'http://127.0.0.1:5000/get-users';
      const response = await fetch(url);
      const data = await response.json();
      setUsers(data); // Обновляем состояние users
      onUserClick(null); // Сбрасываем выбранного пользователя при каждом обновлении списка
    } catch (error) {
      console.error('Ошибка при получении данных:', error);
    }
  };

  useEffect(() => {
    fetchUsers();
    const intervalId = setInterval(() => fetchUsers(searchQuery), 5000);
    return () => clearInterval(intervalId);
  }, [searchQuery]);

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    fetchUsers(searchQuery);
  };

  return (
    <>
      <form className="search-form" onSubmit={handleSearchSubmit}>
        <input
          type="text"
          className="search-input"
          placeholder="Поиск..."
          value={searchQuery}
          onChange={handleSearchChange}
        />
        <button type="submit" className="search-button">Поиск</button>
      </form>
      <table className="UserTableClass">
        <thead>
          <tr>
            <th>ID</th>
            <th>Имя</th>
            <th>Возраст</th>
            <th>Город</th>
          </tr>
        </thead>
        <tbody>
          {users.map(user => (
            <tr
              key={user.id}
              onClick={() => onUserClick(user)}
              style={{
                cursor: 'pointer',
                backgroundColor: user.isSelected ? '#f0f0f0' : 'transparent'
              }}
            >
              <td>{user.id}</td>
              <td>{user.name}</td>
              <td>{user.age}</td>
              <td>{user.city}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
};

export default UsersTable;
