import React, { useState, useEffect } from 'react';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import DraggableComponent from '../components/DraggableComponent';
import DropZone from '../components/DropZone';
import UsersTable from '../components/UsersTable';
import UserDetailModal from '../components/UserDetailModal';
import CreateUserModal from '../components/CreateUserModal';
import IncidentManagement from '../components/IncidentManagement';
import DictionaryManagement from '../components/DictionaryManagement'; // новый компонент
import '../styles/App.css';
import '../styles/UsersTable.css';

function App() {
  const [activeTab, setActiveTab] = useState('users');
  const [components, setComponents] = useState([]);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [users, setUsers] = useState([]);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    const response = await fetch('http://127.0.0.1:5000/get-users');
    const data = await response.json();
    setUsers(data);
  };

  const openCreateModal = () => {
    setIsCreateModalOpen(true);
  };

  const closeCreateModal = () => {
    setIsCreateModalOpen(false);
  };

  const openDetailModal = (user) => {
    if (user) {
      setSelectedUser(user);
      setIsDetailModalOpen(true);
    }
  };

  const closeDetailModal = () => {
    setIsDetailModalOpen(false);
    setSelectedUser(null);
  };

  const handleDrop = (id) => {
    setComponents([...components, id]);
  };

  const handleCreateUser = async (user) => {
    const response = await fetch('http://127.0.0.1:5000/create-user', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(user),
    });

    if (response.ok) {
      fetchUsers();
    }
  };

  return (
    <div className="App">
      <button onClick={() => setActiveTab('users')}>Инциденты</button>
      <button onClick={() => setActiveTab('incident-management')}>Управление инцидентами</button>
      <button onClick={() => setActiveTab('dictionaries')}>Справочники</button> {/* Новая кнопка */}

      {activeTab === 'users' && (
        <>
          <h1>Инциденты</h1>
          <button onClick={openCreateModal}>Создать инцидент</button>
          <UsersTable users={users} onUserClick={openDetailModal} />
        </>
      )}

      {activeTab === 'drag' && (
        <DndProvider backend={HTML5Backend}>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <div>
              <DraggableComponent id="button" type="component">Кнопка</DraggableComponent>
              <DraggableComponent id="input" type="component">Форма ввода</DraggableComponent>
            </div>
            <DropZone onDrop={handleDrop}>
              {components.map((id, index) => (
                <div key={index}>{id === 'button' ? 'Кнопка' : 'Форма ввода'}</div>
              ))}
            </DropZone>
          </div>
        </DndProvider>
      )}

      {activeTab === 'incident-management' && (
        <IncidentManagement />
      )}

      {activeTab === 'dictionaries' && (
        <DictionaryManagement /> 
      )}

      <CreateUserModal isOpen={isCreateModalOpen} onClose={closeCreateModal} onCreate={handleCreateUser} />
      {selectedUser && (
        <UserDetailModal isOpen={isDetailModalOpen} onClose={closeDetailModal} user={selectedUser} />
      )}
    </div>
  );
}

export default App;
