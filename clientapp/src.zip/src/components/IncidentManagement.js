import React, { useState, useEffect } from 'react';
import Modal from 'react-modal';
import FieldModal from './FieldModal';
import axios from 'axios';
import '../styles/IncidentManagement.css';

Modal.setAppElement('#root');

const customStyles = {
    content: {
        top: '50%',
        left: '50%',
        right: 'auto',
        bottom: 'auto',
        marginRight: '-50%',
        transform: 'translate(-50%, -50%)',
        width: '50%',
        padding: '20px',
        background: 'linear-gradient(180deg, #f5f7fa, #c3cfe2)',
        borderRadius: '10px',
        boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)',
    },
};

const IncidentManagement = () => {
    const [organizations, setOrganizations] = useState([]);
    const [selectedOrganization, setSelectedOrganization] = useState(null);
    const [categories, setCategories] = useState([]);
    const [selectedCategory, setSelectedCategory] = useState(null);
    const [types, setTypes] = useState([]);
    const [selectedType, setSelectedType] = useState(null);
    const [fields, setFields] = useState([]);
    const [modalFields, setModalFields] = useState([]);

    const [newName, setNewName] = useState('');
    const [modalIsOpen, setModalIsOpen] = useState(false);
    const [modalType, setModalType] = useState('');
    const [fieldModalIsOpen, setFieldModalIsOpen] = useState(false);

    useEffect(() => {
        fetchOrganizations();
    }, []);

    const fetchOrganizations = async () => {
        const response = await axios.get('http://127.0.0.1:5000/api/organizations');
        setOrganizations(response.data);
        clearSelection();
    };

    const fetchCategories = async (organizationId) => {
        const response = await axios.get(`http://127.0.0.1:5000/api/categories/${organizationId}`);
        setCategories(response.data);
        setSelectedOrganization(organizationId);
        clearCategorySelection();
    };

    const fetchTypes = async (categoryId) => {
        const response = await axios.get(`http://127.0.0.1:5000/api/types/${categoryId}`);
        setTypes(response.data);
        setSelectedCategory(categoryId);
        clearTypeSelection();
    };

    const fetchFields = async (typeId) => {
        const response = await axios.get(`http://127.0.0.1:5000/api/fields/${typeId}`);
        setFields(response.data);
        setSelectedType(typeId);
    };

    const clearSelection = () => {
        setSelectedOrganization(null);
        setSelectedCategory(null);
        setSelectedType(null);
        setCategories([]);
        setTypes([]);
        setFields([]);
    };

    const clearCategorySelection = () => {
        setSelectedCategory(null);
        setSelectedType(null);
        setTypes([]);
        setFields([]);
    };

    const clearTypeSelection = () => {
        setSelectedType(null);
        setFields([]);
    };

    const createOrganization = async () => {
        const response = await axios.post('http://127.0.0.1:5000/api/organizations', { name: newName });
        setOrganizations([...organizations, response.data]);
        setNewName('');
        setModalIsOpen(false);
    };

    const createCategory = async () => {
        const response = await axios.post('http://127.0.0.1:5000/api/categories', { organization_id: selectedOrganization, name: newName });
        setCategories([...categories, response.data]);
        setNewName('');
        setModalIsOpen(false);
    };

    const createType = async () => {
        const response = await axios.post('http://127.0.0.1:5000/api/types', { category_id: selectedCategory, name: newName });
        setTypes([...types, response.data]);
        setNewName('');
        setModalIsOpen(false);
    };

    const createField = async (newFields) => {
        const response = await axios.post('http://127.0.0.1:5000/api/fields', { type_id: selectedType, fields: newFields });
        setFields(prevFields => [...prevFields, ...response.data]);
        setFieldModalIsOpen(false);
    };

    const deleteOrganization = async (organizationId) => {
        await axios.delete(`http://127.0.0.1:5000/api/organizations/${organizationId}`);
        setOrganizations(organizations.filter(org => org.id !== organizationId));
        clearSelection();
    };

    const deleteCategory = async (categoryId) => {
        await axios.delete(`http://127.0.0.1:5000/api/categories/${categoryId}`);
        setCategories(categories.filter(cat => cat.id !== categoryId));
        clearCategorySelection();
    };

    const deleteType = async (typeId) => {
        await axios.delete(`http://127.0.0.1:5000/api/types/${typeId}`);
        setTypes(types.filter(typ => typ.id !== typeId));
        clearTypeSelection();
    };

    const deleteField = async (fieldId) => {
        await axios.delete(`http://127.0.0.1:5000/api/fields/${fieldId}`);
        setFields(fields.filter(field => field.id !== fieldId));
    };

    const openModal = (type) => {
        setModalType(type);
        setModalIsOpen(true);
    };

    const closeModal = () => {
        setModalIsOpen(false);
    };

    const openFieldModal = () => {
        setFieldModalIsOpen(true);
        setModalFields(fields); // Show existing fields in modal
    };

    const closeFieldModal = () => {
        setFieldModalIsOpen(false);
    };

    const renderTable = (data, onClick, placeholder) => {
        let deleteFunction;
        switch (placeholder) {
            case 'Организации':
                deleteFunction = deleteOrganization;
                break;
            case 'Категории':
                deleteFunction = deleteCategory;
                break;
            case 'Типы':
                deleteFunction = deleteType;
                break;
            case 'Поля':
                deleteFunction = deleteField;
                break;
            default:
                break;
        }

        return (
            <div className="table-container">
                <table className="styled-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>{placeholder}</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.map(item => (
                            <tr key={item.id}>
                                <td>{item.id}</td>
                                <td onClick={() => onClick(item.id)}>{item.field_type ? `${item.field_type} (${item.name})` : item.name}</td>
                                <td>
                                    <div className="action-button">
                                        <button>Действия</button>
                                        <div className="dropdown-content">
                                            <button onClick={() => deleteFunction(item.id)}>Удалить</button>
                                            <button>Изменить</button>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        ))}
                        <tr className="no-hover">
                            <td colSpan="3" className="add-row">
                                <button className="add-button" onClick={() => {
                                    if (placeholder.toLowerCase() === 'поля') {
                                        openFieldModal();
                                    } else {
                                        openModal(placeholder.toLowerCase());
                                    }
                                }}>
                                    Добавить {placeholder.toLowerCase()}
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        );
    };

    const renderModalContent = () => {
        switch (modalType) {
            case 'организации':
                return (
                    <div>
                        <h2>Создать организацию</h2>
                        <input
                            type="text"
                            placeholder="Название организации"
                            value={newName}
                            onChange={(e) => setNewName(e.target.value)}
                        />
                        <button onClick={createOrganization}>Создать</button>
                        <button onClick={closeModal}>Отменить</button>
                    </div>
                );
            case 'категории':
                return (
                    <div>
                        <h2>Создать категорию</h2>
                        <input
                            type="text"
                            placeholder="Название категории"
                            value={newName}
                            onChange={(e) => setNewName(e.target.value)}
                        />
                        <button onClick={createCategory}>Создать</button>
                        <button onClick={closeModal}>Отменить</button>
                    </div>
                );
            case 'типы':
                return (
                    <div>
                        <h2>Создать тип</h2>
                        <input
                            type="text"
                            placeholder="Название типа"
                            value={newName}
                            onChange={(e) => setNewName(e.target.value)}
                        />
                        <button onClick={createType}>Создать</button>
                        <button onClick={closeModal}>Отменить</button>
                    </div>
                );
            default:
                return null;
        }
    };

    return (
        <div>
            <h1>Управление инцидентами</h1>
            <div className="main-table">
                <div className="breadcrumb">
                    <span onClick={fetchOrganizations}>Организации</span>
                    {selectedOrganization && (
                        <>
                            <span onClick={() => fetchCategories(selectedOrganization)}>
                                {organizations.find(org => org.id === selectedOrganization)?.name}
                            </span>
                        </>
                    )}
                    {selectedCategory && (
                        <>
                            <span onClick={() => fetchTypes(selectedCategory)}>
                                {categories.find(cat => cat.id === selectedCategory)?.name}
                            </span>
                        </>
                    )}
                    {selectedType && (
                        <>
                            <span onClick={() => fetchFields(selectedType)}>
                                {types.find(typ => typ.id === selectedType)?.name}
                            </span>
                        </>
                    )}
                </div>
                {!selectedOrganization && renderTable(organizations, fetchCategories, 'Организации')}
                {selectedOrganization && !selectedCategory && renderTable(categories, fetchTypes, 'Категории')}
                {selectedCategory && !selectedType && renderTable(types, fetchFields, 'Типы')}
                {selectedType && renderTable(fields, () => {}, 'Поля')}
            </div>
            <Modal
                isOpen={modalIsOpen}
                onRequestClose={closeModal}
                style={customStyles}
                contentLabel="Создать"
            >
                {renderModalContent()}
            </Modal>
            <FieldModal
                modalIsOpen={fieldModalIsOpen}
                closeModal={closeFieldModal}
                fields={modalFields}
                setFields={setModalFields}
                createField={createField}
            />
        </div>
    );
};

export default IncidentManagement;
