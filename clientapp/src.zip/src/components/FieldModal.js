import React, { useState, useEffect } from 'react';
import Modal from 'react-modal';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import FieldType from './FieldType';
import DropZone from './DropZone';
import axios from 'axios';

Modal.setAppElement('#root');

const customStyles = {
    content: {
        top: '50%',
        left: '50%',
        right: 'auto',
        bottom: 'auto',
        marginRight: '-50%',
        transform: 'translate(-50%, -50%)',
        width: '50%',
        padding: '20px',
        background: 'linear-gradient(180deg, #f5f7fa, #c3cfe2)',
        borderRadius: '10px',
        boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)',
    },
};

const FieldModal = ({
    modalIsOpen,
    closeModal,
    fields,
    setFields,
    createField,
}) => {
    const [dictionaries, setDictionaries] = useState([]);

    useEffect(() => {
        fetchDictionaries();
    }, []);

    const fetchDictionaries = async () => {
        const response = await axios.get('http://127.0.0.1:5000/api/dictionaries');
        setDictionaries(response.data);
    };

    const handleDrop = (item) => {
        const newField = { ...item, name: '', dictionaries: dictionaries };
        setFields(prevFields => [...prevFields, newField]);
    };

    const handleFieldNameChange = (index, name) => {
        setFields(prevFields => {
            const updatedFields = [...prevFields];
            updatedFields[index].name = name;
            return updatedFields;
        });
    };

    const handleSelectDictionary = (index, dictionaryId) => {
        const selectedDictionary = dictionaries.find(dict => dict.id === parseInt(dictionaryId));
        setFields(prevFields => {
            const updatedFields = [...prevFields];
            updatedFields[index].name = `Справочник (${selectedDictionary.name})`;
            updatedFields[index].dictionary_id = dictionaryId;
            return updatedFields;
        });
    };

    const handleRemoveField = (index) => {
        setFields(prevFields => {
            const updatedFields = [...prevFields];
            updatedFields.splice(index, 1);
            return updatedFields;
        });
    };

    const handleCreateField = () => {
        if (fields.some(field => field.name === '')) {
            alert('Заполните все поля именами');
            return;
        }
        createField(fields.filter(field => !field.id));
        closeModal();
    };

    return (
        <Modal
            isOpen={modalIsOpen}
            onRequestClose={closeModal}
            style={customStyles}
            contentLabel="Создать поле"
        >
            <div>
                <h2>Создать поле</h2>
                <DndProvider backend={HTML5Backend}>
                    <div className="field-types">
                        {['Дата', 'Текст', 'Номер', 'Выпадающий список', 'Справочник', 'Чек бокс', 'Дата и время создания', 'Дата и время изменения'].map((type) => (
                            <FieldType key={type} type={type} />
                        ))}
                    </div>
                    <DropZone
                        fields={fields}
                        onDrop={handleDrop}
                        handleFieldNameChange={handleFieldNameChange}
                        handleSelectDictionary={handleSelectDictionary}
                        handleRemoveField={handleRemoveField}
                    />
                </DndProvider>
                <button onClick={handleCreateField}>Создать</button>
                <button onClick={closeModal}>Отменить</button>
            </div>
        </Modal>
    );
};

export default FieldModal;
