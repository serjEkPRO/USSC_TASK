import React from 'react';
import { useDrop } from 'react-dnd';

const DropZone = ({ fields, onDrop, handleFieldNameChange, handleSelectDictionary, handleRemoveField }) => {
    const [{ isOver }, drop] = useDrop(() => ({
        accept: 'FIELD',
        drop: (item) => onDrop(item),
        collect: (monitor) => ({
            isOver: !!monitor.isOver(),
        }),
    }));

    return (
        <div
            ref={drop}
            style={{
                minHeight: '100px',
                border: '2px dashed #ccc',
                borderRadius: '5px',
                padding: '10px',
                marginTop: '10px',
                backgroundColor: isOver ? '#f5f5f5' : 'white',
                overflowY: 'auto',
                maxHeight: '300px',
            }}
        >
            {fields.map((field, index) => (
                <div key={index} style={{ padding: '10px', backgroundColor: '#f5f5f5', marginBottom: '5px', border: '1px solid #ddd', borderRadius: '5px', position: 'relative' }}>
                    {field.field_type !== 'Справочник' ? (
                        <>
                            <input
                                type="text"
                                value={field.name}
                                placeholder="Введите имя"
                                onChange={(e) => handleFieldNameChange(index, e.target.value)}
                                style={{
                                    border: field.name === '' ? '1px solid red' : '1px solid #ddd',
                                    padding: '5px',
                                    borderRadius: '5px',
                                    width: 'calc(100% - 10px)',
                                }}
                            />
                            {field.name === '' && (
                                <span style={{ color: 'red', position: 'absolute', top: '-20px', left: '10px' }}>Введите имя</span>
                            )}
                        </>
                    ) : (
                        <div>
                            <label>Выберите справочник:</label>
                            <select
                                value={field.dictionary_id || ''}
                                onChange={(e) => handleSelectDictionary(index, e.target.value)}
                                style={{
                                    border: '1px solid #ddd',
                                    padding: '5px',
                                    borderRadius: '5px',
                                    width: 'calc(100% - 10px)',
                                }}
                            >
                                <option value="" disabled>Выберите справочник</option>
                                {field.dictionaries.map((dict) => (
                                    <option key={dict.id} value={dict.id}>{dict.name}</option>
                                ))}
                            </select>
                        </div>
                    )}
                    <button
                        onClick={() => handleRemoveField(index)}
                        style={{
                            position: 'absolute',
                            top: '5px',
                            right: '5px',
                            background: 'red',
                            color: 'white',
                            border: 'none',
                            borderRadius: '50%',
                            width: '20px',
                            height: '20px',
                            textAlign: 'center',
                            cursor: 'pointer',
                        }}
                    >
                        &times;
                    </button>
                </div>
            ))}
        </div>
    );
};

export default DropZone;
