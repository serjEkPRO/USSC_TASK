import React, { useState } from 'react';
import mammoth from 'mammoth';
import htmlDocx from 'html-docx-js/dist/html-docx';
import '../styles/DocumentEditor.css';


const DocumentEditor = () => {
  const [documentContent, setDocumentContent] = useState('');
  const [documentTitle, setDocumentTitle] = useState('Untitled Document');

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (file && file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
      const reader = new FileReader();
      reader.onload = async (event) => {
        const arrayBuffer = event.target.result;
        const result = await mammoth.convertToHtml({ arrayBuffer });
        setDocumentContent(result.value);
        setDocumentTitle(file.name.replace('.docx', ''));
      };
      reader.readAsArrayBuffer(file);
    } else {
      alert('Please upload a valid .docx file');
    }
  };

  const handleDownload = () => {
    if (typeof window !== 'undefined') {
      const content = `<!DOCTYPE html><html><body>${documentContent}</body></html>`;
      const converted = htmlDocx.asBlob(content);
      const element = window.document.createElement('a');
      element.href = URL.createObjectURL(converted);
      element.download = `${documentTitle}.docx`;

      if (window.document.body) {
        window.document.body.appendChild(element);
        element.click();
        window.document.body.removeChild(element);
      }
    }
  };

  return (
    <div className="document-editor-container">
      <input type="file" onChange={handleFileUpload} accept=".docx" />
      <input
        type="text"
        value={documentTitle}
        onChange={(e) => setDocumentTitle(e.target.value)}
        placeholder="Document Title"
      />
      <div className="editor-content" contentEditable dangerouslySetInnerHTML={{ __html: documentContent }} />
      <button onClick={handleDownload}>Download as .docx</button>
    </div>
  );
};

export default DocumentEditor;
