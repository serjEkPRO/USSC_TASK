import React, { useState } from 'react';
import htmlDocx from 'html-docx-js/dist/html-docx';

const DocumentsList = ({ documents }) => {
  const [selectedDoc, setSelectedDoc] = useState(null);

  const handleDownload = (doc) => {
    if (typeof window !== 'undefined') {
      const content = `<!DOCTYPE html><html><body>${doc.content}</body></html>`;
      const converted = htmlDocx.asBlob(content);
      const element = window.document.createElement('a');
      element.href = URL.createObjectURL(converted);
      element.download = `${doc.title}.docx`;

      if (window.document.body) {
        window.document.body.appendChild(element);
        element.click();
        window.document.body.removeChild(element);
      }
    }
  };

  const handleView = (doc) => {
    setSelectedDoc(doc);
  };

  return (
    <div className="documents-container">
      <div className="documents-list">
        <h3>Documents</h3>
        <ul>
          {documents.map((doc, index) => (
            <li key={index}>
              <span onClick={() => handleView(doc)} style={{ cursor: 'pointer' }}>
                {doc.title}
              </span>
              <button onClick={() => handleDownload(doc)}>Download</button>
            </li>
          ))}
        </ul>
      </div>
      <div className="document-viewer">
        {selectedDoc ? (
          <div>
            <h4>{selectedDoc.title}</h4>
            <div dangerouslySetInnerHTML={{ __html: selectedDoc.content }} />
          </div>
        ) : (
          <p>Select a document to view its content</p>
        )}
      </div>
    </div>
  );
};

export default DocumentsList;
