import React from 'react';

const DraggableNode = ({ node }) => {
  const onDragStart = (event) => {
    event.dataTransfer.setData('application/reactflow', node.id);
    event.dataTransfer.effectAllowed = 'move';
  };

  return (
    <div
      className="draggable-node"
      onDragStart={onDragStart}
      draggable
      style={{
        opacity: 1,
      }}
    >
      {node.label}
    </div>
  );
};

export default DraggableNode;
