import React from 'react';
import '../styles/Background.css';

const Background = () => (
  <div className="background">
    {/* Ваш SVG или другие элементы фона */}
  </div>
);

export default Background;
