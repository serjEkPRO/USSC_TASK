import React from 'react';
import DraggableNode from './DraggableNode';

const NodeSelector = () => {
  const nodes = [
    { id: 'python-script', label: 'Python Script Node' },
    { id: 'logic-node', label: 'Logic Node' },
  ];

  return (
    <div className="node-selector">
      <h3>Select a Node</h3>
      {nodes.map((node) => (
        <DraggableNode key={node.id} node={node} />
      ))}
    </div>
  );
};

export default NodeSelector;
