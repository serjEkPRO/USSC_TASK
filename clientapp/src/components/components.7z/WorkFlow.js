import React, { useRef, useCallback, useState } from 'react';
import {
  ReactFlow,
  ReactFlowProvider,
  addEdge,
  useNodesState,
  useEdgesState,
  Controls,
  Background,
  useReactFlow,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';

import CustomEdge from './CustomEdge';
import NodeSelector from './NodeSelector';
import '../styles/workflow.scss';

const initialNodes = [
  { id: 'a', type: 'input', position: { x: 0, y: 0 }, data: { label: 'Node A' } },
  { id: 'b', position: { x: 200, y: 100 }, data: { label: 'Node B' } },
  { id: 'c', position: { x: 400, y: 200 }, data: { label: 'Node C' } },
];

const initialEdges = [
  { id: 'a->b', type: 'custom-edge', source: 'a', target: 'b', data: { label: 'Edge A-B' } },
  { id: 'b->c', type: 'custom-edge', source: 'b', target: 'c', data: { label: 'Edge B-C' } },
];

let id = 0;
const getId = () => `dndnode_${id++}`;

function WorkFlow() {
  const reactFlowWrapperRef = useRef(null);
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
  const [cursorPosition, setCursorPosition] = useState({ x: 0, y: 0 });
  const { screenToFlowPosition } = useReactFlow();

  const GRID_SIZE = 50;

  const snapToGrid = (x, y) => {
    const snappedX = Math.round(x / GRID_SIZE) * GRID_SIZE;
    const snappedY = Math.round(y / GRID_SIZE) * GRID_SIZE;
    return { x: snappedX, y: snappedY };
  };

  const onConnect = useCallback(
    (connection) => setEdges((eds) => addEdge(connection, eds)),
    []
  );

  const onDragOver = useCallback((event) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';

    const reactFlowBounds = reactFlowWrapperRef.current.getBoundingClientRect();
    const x = event.clientX - reactFlowBounds.left;
    const y = event.clientY - reactFlowBounds.top;

    const snappedPosition = snapToGrid(x, y);
    setCursorPosition(snappedPosition);
  }, []);

  const onDrop = useCallback(
    (event) => {
      event.preventDefault();

      const type = event.dataTransfer.getData('application/reactflow');

      if (!type) {
        console.error("Node type is not defined.");
        return;
      }

      const reactFlowBounds = reactFlowWrapperRef.current.getBoundingClientRect();
      const x = event.clientX - reactFlowBounds.left;
      const y = event.clientY - reactFlowBounds.top;

      const flowPosition = screenToFlowPosition({ x, y });

      console.log(`Screen position: x=${event.clientX}, y=${event.clientY}`);
      console.log(`Flow position: x=${flowPosition.x}, y=${flowPosition.y}`);

      const newNode = {
        id: getId(),
        type,
        position: flowPosition,
        data: { label: `${type} Node` },
      };

      setNodes((nds) => nds.concat(newNode));
    },
    [screenToFlowPosition, setNodes]
  );

  const onMouseMove = useCallback((event) => {
    const reactFlowBounds = reactFlowWrapperRef.current.getBoundingClientRect();
    const x = event.clientX - reactFlowBounds.left;
    const y = event.clientY - reactFlowBounds.top;

    setCursorPosition({ x, y });

    console.log(`Cursor position - x: ${x}, y: ${y}`);
  }, []);

  return (
    <div className="workflow-container">
      <div className="node-selector-container">
        <NodeSelector />
      </div>
      <div
        className="reactflow-wrapper"
        ref={reactFlowWrapperRef}
        onMouseMove={onMouseMove}
        onDragOver={onDragOver}
        onDrop={onDrop}
      >
        <ReactFlowProvider>
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onConnect={onConnect}
            edgeTypes={{ 'custom-edge': CustomEdge }}
            fitView
          >
            <Controls />
            <Background gap={GRID_SIZE} />
          </ReactFlow>
        </ReactFlowProvider>
        <div className="cursor-coordinates">
          x: {cursorPosition.x.toFixed(0)}, y: {cursorPosition.y.toFixed(0)}
        </div>
      </div>
    </div>
  );
}

export default WorkFlow;
