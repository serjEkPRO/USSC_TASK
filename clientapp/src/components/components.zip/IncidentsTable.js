import React, { useEffect, useState } from 'react';
import '../styles/UsersTable.css';

const IncidentsTable = ({ initialIncidents = [], onIncidentClick }) => {
  const [incidents, setIncidents] = useState(initialIncidents);
  const [searchQuery, setSearchQuery] = useState('');

  const fetchIncidents = async (query = '') => {
    try {
      const url = query ? `http://127.0.0.1:5000/api/search-incidents?query=${query}` : 'http://127.0.0.1:5000/api/incidents';
      const response = await fetch(url);
      const data = await response.json();
      setIncidents(data);
      onIncidentClick(null);
    } catch (error) {
      console.error('Ошибка при получении данных:', error);
    }
  };

  useEffect(() => {
    fetchIncidents();
    const intervalId = setInterval(() => fetchIncidents(searchQuery), 5000);
    return () => clearInterval(intervalId);
  }, [searchQuery]);

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    fetchIncidents(searchQuery);
  };

  return (
    <>
      <form className="search-form" onSubmit={handleSearchSubmit}>
        <input
          type="text"
          className="search-input"
          placeholder="Поиск..."
          value={searchQuery}
          onChange={handleSearchChange}
        />
        <button type="submit" className="search-button">Поиск</button>
      </form>
      <table className="UserTableClass">
        <thead>
          <tr>
            <th>ID</th>
            <th>Организация</th>
            <th>Категория</th>
            <th>Тип</th>
            <th>Создатель</th>
            <th>Ответственный</th>
            <th>Дата создания</th>
            <th>Дата изменения</th>
          </tr>
        </thead>
        <tbody>
          {incidents.map(incident => (
            <tr
              key={incident.id}
              onClick={() => onIncidentClick(incident)}
              style={{
                cursor: 'pointer',
                backgroundColor: incident.isSelected ? '#f0f0f0' : 'transparent'
              }}
            >
              <td>{incident.id}</td>
              <td>{incident.organization_id}</td>
              <td>{incident.category_id}</td>
              <td>{incident.type_id}</td>
              <td>{incident.creator}</td>
              <td>{incident.responsible}</td>
              <td>{incident.created_at}</td>
              <td>{incident.updated_at}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
};

export default IncidentsTable;
