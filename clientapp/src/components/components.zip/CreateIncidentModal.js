import React, { useState, useEffect } from 'react';
import '../styles/CreateIncidentModal.css';

const CreateIncidentModal = ({ isOpen, onClose, onCreate }) => {
  const [organizations, setOrganizations] = useState([]);
  const [categories, setCategories] = useState([]);
  const [types, setTypes] = useState([]);
  const [fields, setFields] = useState([]);
  const [selectedOrganization, setSelectedOrganization] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [selectedType, setSelectedType] = useState(null);
  const [formValues, setFormValues] = useState({});

  useEffect(() => {
    fetchOrganizations();
  }, []);

  const fetchOrganizations = async () => {
    const response = await fetch('/api/organizations');
    const data = await response.json();
    setOrganizations(data);
  };

  const fetchCategories = async (organizationId) => {
    const response = await fetch(`/api/categories/${organizationId}`);
    const data = await response.json();
    setCategories(data);
  };

  const fetchTypes = async (categoryId) => {
    const response = await fetch(`/api/types/${categoryId}`);
    const data = await response.json();
    setTypes(data);
  };

  const fetchFields = async (typeId) => {
    const response = await fetch(`/api/fields/${typeId}`);
    const data = await response.json();
    setFields(data);
  };

  const handleOrganizationChange = (e) => {
    const organizationId = e.target.value;
    setSelectedOrganization(organizationId);
    fetchCategories(organizationId);
  };

  const handleCategoryChange = (e) => {
    const categoryId = e.target.value;
    setSelectedCategory(categoryId);
    fetchTypes(categoryId);
  };

  const handleTypeChange = (e) => {
    const typeId = e.target.value;
    setSelectedType(typeId);
    fetchFields(typeId);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormValues({ ...formValues, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onCreate(formValues);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="modal">
      <div className="modal-content">
        <span className="close" onClick={onClose}>&times;</span>
        <h2>Создать инцидент</h2>
        <form onSubmit={handleSubmit}>
          <label>Организация:</label>
          <select onChange={handleOrganizationChange}>
            <option value="">Выберите организацию</option>
            {organizations.map(org => (
              <option key={org.id} value={org.id}>{org.name}</option>
            ))}
          </select>

          <label>Категория инцидента:</label>
          <select onChange={handleCategoryChange}>
            <option value="">Выберите категорию</option>
            {categories.map(cat => (
              <option key={cat.id} value={cat.id}>{cat.name}</option>
            ))}
          </select>

          <label>Тип инцидента:</label>
          <select onChange={handleTypeChange}>
            <option value="">Выберите тип</option>
            {types.map(type => (
              <option key={type.id} value={type.id}>{type.name}</option>
            ))}
          </select>

          {fields.map(field => (
            <div key={field.id}>
              <label>{field.name}:</label>
              <input type={field.field_type} name={field.name} onChange={handleInputChange} />
            </div>
          ))}

          <label>Свидетельства (имя файла):</label>
          <input type="text" name="evidence_name" onChange={handleInputChange} />

          <label>Свидетельства (ссылка):</label>
          <input type="text" name="evidence_link" onChange={handleInputChange} />

          <label>Создатель:</label>
          <input type="text" name="creator" onChange={handleInputChange} />

          <label>Ответственный:</label>
          <input type="text" name="responsible" onChange={handleInputChange} />

          <button type="submit">Создать</button>
        </form>
      </div>
    </div>
  );
};

export default CreateIncidentModal;
