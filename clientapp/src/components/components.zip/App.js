import React, { useState, useEffect } from 'react';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import DraggableComponent from '../components/DraggableComponent';
import DropZone from '../components/DropZone';
import IncidentsTable from '../components/IncidentsTable';
import IncidentDetailModal from '../components/IncidentDetailModal';
import CreateIncidentModal from '../components/CreateIncidentModal';
import IncidentManagement from '../components/IncidentManagement';
import DictionaryManagement from '../components/DictionaryManagement';

import '../styles/App.css';
import '../styles/UsersTable.css';

function App() {
  const [activeTab, setActiveTab] = useState('incidents');
  const [components, setComponents] = useState([]);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [selectedIncident, setSelectedIncident] = useState(null);
  const [incidents, setIncidents] = useState([]);

  useEffect(() => {
    fetchIncidents();
  }, []);

  const fetchIncidents = async () => {
    const response = await fetch('http://127.0.0.1:5000/api/incidents');
    const data = await response.json();
    setIncidents(data);
  };

  const openCreateModal = () => {
    setIsCreateModalOpen(true);
  };

  const closeCreateModal = () => {
    setIsCreateModalOpen(false);
  };

  const openDetailModal = (incident) => {
    if (incident) {
      setSelectedIncident(incident);
      setIsDetailModalOpen(true);
    }
  };

  const closeDetailModal = () => {
    setIsDetailModalOpen(false);
    setSelectedIncident(null);
  };

  const handleDrop = (id) => {
    setComponents([...components, id]);
  };

  const handleCreateIncident = async (incident) => {
    const response = await fetch('http://127.0.0.1:5000/api/incidents', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(incident),
    });

    if (response.ok) {
      fetchIncidents();
    }
  };

  return (
    <div className="App">
      <button onClick={() => setActiveTab('incidents')}>Инциденты</button>
      <button onClick={() => setActiveTab('incident-management')}>Управление инцидентами</button>
      <button onClick={() => setActiveTab('dictionaries')}>Справочники</button>

      {activeTab === 'incidents' && (
        <>
          <h1>Инциденты</h1>
          <button onClick={openCreateModal}>Создать инцидент</button>
          <IncidentsTable incidents={incidents} onIncidentClick={openDetailModal} />
        </>
      )}

      {activeTab === 'drag' && (
        <DndProvider backend={HTML5Backend}>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <div>
              <DraggableComponent id="button" type="component">Кнопка</DraggableComponent>
              <DraggableComponent id="input" type="component">Форма ввода</DraggableComponent>
            </div>
            <DropZone onDrop={handleDrop}>
              {components.map((id, index) => (
                <div key={index}>{id === 'button' ? 'Кнопка' : 'Форма ввода'}</div>
              ))}
            </DropZone>
          </div>
        </DndProvider>
      )}

      {activeTab === 'incident-management' && (
        <IncidentManagement />
      )}

      {activeTab === 'dictionaries' && (
        <DictionaryManagement /> 
      )}

      <CreateIncidentModal isOpen={isCreateModalOpen} onClose={closeCreateModal} onCreate={handleCreateIncident} />
      {selectedIncident && (
        <IncidentDetailModal isOpen={isDetailModalOpen} onClose={closeDetailModal} incident={selectedIncident} />
      )}
    </div>
  );
}

export default App;
