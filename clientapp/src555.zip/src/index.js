import React from 'react';
import ReactDOM from 'react-dom';
import './styles/index.css'; // Глобальные стили приложения

import App from './components/App'; // Корневой компонент приложения
//import reportWebVitals from './reportWebVitals';

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root') // Монтирование компонента App в элемент с id 'root'
);

// Если вы хотите начать измерять производительность в вашем приложении, передайте функцию
// для логирования результатов (например: reportWebVitals(console.log))
// или отправки в аналитический конечный пункт. Узнайте больше: https://bit.ly/CRA-vitals
//reportWebVitals();
