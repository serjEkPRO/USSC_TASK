import React from 'react';
import { useDrop } from 'react-dnd';

const DropZone = ({ fields, onDrop }) => {
    const [{ isOver }, drop] = useDrop({
        accept: 'field',
        drop: (item) => onDrop(item),
        collect: (monitor) => ({
            isOver: !!monitor.isOver(),
        }),
    });

    return (
        <div ref={drop} className="drop-zone">
            {fields.map((field, index) => (
                <div key={index} className="field">
                    {field.name} ({field.field_type})
                </div>
            ))}
            {isOver && <div className="overlay">Перетащите поле сюда</div>}
        </div>
    );
};

export default DropZone;
