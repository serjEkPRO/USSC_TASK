import React from 'react';
import { useDrag } from 'react-dnd';

const FieldType = ({ type }) => {
    const [{ isDragging }, drag] = useDrag({
        type: 'field', // Добавьте этот параметр
        item: { name: type, field_type: type },
        collect: (monitor) => ({
            isDragging: !!monitor.isDragging(),
        }),
    });

    return (
        <div ref={drag} className="field-type" style={{ opacity: isDragging ? 0.5 : 1 }}>
            {type}
        </div>
    );
};

export default FieldType;
